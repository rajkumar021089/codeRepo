Reserved for package configuration.
