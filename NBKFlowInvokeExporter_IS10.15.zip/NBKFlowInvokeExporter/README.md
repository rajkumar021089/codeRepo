# NBKFlowInvokeExporter

Read-only static dependency exporter for IBM webMethods Integration Server 10.15.

Invoke the Flow service:

`NBKFlowInvokeExporter.services:exportPackageInvokes`

Required input:

- `packageName`: one installed package name, for example `NBKCmrPayment`.

Optional inputs:

- `outputFileName`: simple `.csv` filename. The default is `<packageName>_REST_Flow_Invokes.csv`.
- `includeDisabled`: `false` by default; set `true` to include INVOKEs inside disabled Flow branches.

The CSV has exactly three columns:

```text
api_name,parent_service_name,child_invoke_service_name
```

Only called services that resolve to packages beginning with `NBK` are included.
The package `NBKLoggingPub` is always excluded. Child services are followed recursively,
cycles are stopped, and duplicate API/parent/child rows are removed. Within each API and
parent, child rows retain their first-seen, depth-first Flow INVOKE order.

The package includes the Eclipse Java-project metadata required to open its Java helper in
Designer 10.15.

See `INSTALLATION.md` for installation, execution, output, and limitations.
