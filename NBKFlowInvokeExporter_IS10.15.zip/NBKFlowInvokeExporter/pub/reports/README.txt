Generated CSV reports are written to this directory.
