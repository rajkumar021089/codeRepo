package NBKFlowInvokeExporter;

// -----( IS Java Code Template v1.2

import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.app.b2b.server.ServiceException;
import com.wm.app.b2b.server.ServerAPI;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.DirectoryStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public final class internal {

    private static final String PACKAGE_ID = "NBKFlowInvokeExporter";
    private static final String CHILD_PACKAGE_PREFIX = "NBK";
    private static final String EXCLUDED_PACKAGE = "NBKLoggingPub";
    private static final long MAX_XML_BYTES = 32L * 1024L * 1024L;
    private static final Set<String> REST_OPERATION_NAMES = new HashSet<String>(Arrays.asList(
            "_get", "_post", "_put", "_patch", "_delete", "_default"));
    private static final Pattern PACKAGE_NAME_PATTERN = Pattern.compile("[A-Za-z0-9_$-]+");
    private static final Pattern OUTPUT_FILE_PATTERN = Pattern.compile("[A-Za-z0-9_$][A-Za-z0-9_$.-]{0,199}\\.csv", Pattern.CASE_INSENSITIVE);
    private static final Pattern SERVICE_REFERENCE_PATTERN = Pattern.compile(
            "(?<![A-Za-z0-9_$.-])"
            + "([A-Za-z_$][A-Za-z0-9_$-]*(?:\\.[A-Za-z_$][A-Za-z0-9_$-]*)*"
            + ":[A-Za-z_$][A-Za-z0-9_$-]*)"
            + "(?![A-Za-z0-9_$.-])");

    final static internal _instance = new internal();

    static internal _newInstance() {
        return new internal();
    }

    static internal _cast(Object object) {
        return (internal) object;
    }

    // ---( server methods )---

    public static final void scanAndExport(IData pipeline) throws ServiceException {
        // --- <<IS-START(scanAndExport)>> ---
        // @sigtype java 3.5
        // [i] field:0:required packageName
        // [i] field:0:optional outputFileName
        // [i] field:0:optional includeDisabled {"false","true"}
        // [o] field:0:required status
        // [o] field:0:required csvFileName
        // [o] field:0:required csvPath
        // [o] field:0:required apiCount
        // [o] field:0:required parentServiceCount
        // [o] field:0:required rowCount
        // [o] field:0:required warningCount
        // [o] field:1:required warnings
        // [o] field:0:required csvData
        IDataCursor cursor = pipeline.getCursor();
        try {
            String packageName = trimToNull(IDataUtil.getString(cursor, "packageName"));
            String outputFileName = trimToNull(IDataUtil.getString(cursor, "outputFileName"));
            boolean includeDisabled = parseBoolean(IDataUtil.getString(cursor, "includeDisabled"));

            if (packageName == null || !PACKAGE_NAME_PATTERN.matcher(packageName).matches()) {
                throw new IllegalArgumentException(
                        "packageName is required and may contain only letters, digits, underscore, dollar sign, or hyphen");
            }

            File configDirectory = ServerAPI.getPackageConfigDir(PACKAGE_ID);
            if (configDirectory == null || configDirectory.getParentFile() == null
                    || configDirectory.getParentFile().getParentFile() == null) {
                throw new IllegalStateException("Unable to resolve the Integration Server packages directory");
            }

            Path exporterPackageDirectory = configDirectory.getParentFile().toPath().toAbsolutePath().normalize();
            Path packagesDirectory = exporterPackageDirectory.getParent().toAbsolutePath().normalize();
            Path reportsDirectory = exporterPackageDirectory.resolve("pub").resolve("reports").normalize();

            ExportResult result = executeScan(
                    packagesDirectory, packageName, reportsDirectory, outputFileName, includeDisabled);

            IDataUtil.put(cursor, "status", "SUCCESS");
            IDataUtil.put(cursor, "csvFileName", result.csvFileName);
            IDataUtil.put(cursor, "csvPath", result.csvPath.toString());
            IDataUtil.put(cursor, "apiCount", Integer.toString(result.apiCount));
            IDataUtil.put(cursor, "parentServiceCount", Integer.toString(result.parentServiceCount));
            IDataUtil.put(cursor, "rowCount", Integer.toString(result.rowCount));
            IDataUtil.put(cursor, "warningCount", Integer.toString(result.warnings.size()));
            IDataUtil.put(cursor, "warnings", result.warnings.toArray(new String[result.warnings.size()]));
            IDataUtil.put(cursor, "csvData", result.csvData);
        } catch (Exception exception) {
            throw new ServiceException(exception);
        } finally {
            cursor.destroy();
        }
        // --- <<IS-END>> ---
    }

    // ---( implementation helpers )---

    static ExportResult executeScan(
            Path packagesDirectory,
            String requestedPackageName,
            Path reportsDirectory,
            String requestedOutputFileName,
            boolean includeDisabled) throws Exception {

        Path normalizedPackagesDirectory = packagesDirectory.toAbsolutePath().normalize();
        if (!Files.isDirectory(normalizedPackagesDirectory)) {
            throw new IllegalArgumentException(
                    "Integration Server packages directory does not exist: " + normalizedPackagesDirectory);
        }

        Path selectedPackageDirectory = findPackageDirectory(
                normalizedPackagesDirectory, requestedPackageName);
        String actualPackageName = selectedPackageDirectory.getFileName().toString();
        String outputFileName = validateOutputFileName(
                requestedOutputFileName, actualPackageName + "_REST_Flow_Invokes.csv");

        LinkedHashSet<String> warnings = new LinkedHashSet<String>();
        Map<String, List<ServiceEntry>> serviceIndex = buildServiceIndex(
                normalizedPackagesDirectory, warnings);

        DiscoveryResult discoveryResult = discoverRestResources(
                selectedPackageDirectory, serviceIndex, warnings);

        FlowGraph graph = new FlowGraph(serviceIndex, includeDisabled, warnings);
        Set<Row> rows = new TreeSet<Row>(ROW_COMPARATOR);
        Set<String> apiNames = new TreeSet<String>(STRING_COMPARATOR);

        for (RestResource resource : discoveryResult.resources) {
            apiNames.add(resource.apiName);
            Set<String> children = graph.recursiveChildren(resource.parentServiceName);
            for (String child : children) {
                rows.add(new Row(resource.apiName, resource.parentServiceName, child));
            }
        }

        if (!graph.unresolvedNbKTargets.isEmpty()) {
            warnings.add(
                    "NBK-looking INVOKE targets not found in scanned packages: "
                    + join(graph.unresolvedNbKTargets, ", "));
        }

        String csvData = buildCsv(rows);
        Path csvPath = writeCsvAtomically(reportsDirectory, outputFileName, csvData);

        return new ExportResult(
                outputFileName,
                csvPath,
                apiNames.size(),
                discoveryResult.resources.size(),
                rows.size(),
                new ArrayList<String>(warnings),
                csvData);
    }

    private static Path findPackageDirectory(Path packagesDirectory, String requestedName) throws IOException {
        List<Path> matches = new ArrayList<Path>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(packagesDirectory)) {
            for (Path path : stream) {
                if (Files.isDirectory(path) && !Files.isSymbolicLink(path)
                        && path.getFileName().toString().equalsIgnoreCase(requestedName)) {
                    matches.add(path.toAbsolutePath().normalize());
                }
            }
        }
        if (matches.isEmpty()) {
            throw new IllegalArgumentException("Package not found: " + requestedName);
        }
        if (matches.size() > 1) {
            throw new IllegalArgumentException("Package name is ambiguous by case: " + requestedName);
        }
        Path packageDirectory = matches.get(0);
        if (!packageDirectory.startsWith(packagesDirectory)) {
            throw new IllegalArgumentException("Resolved package is outside the packages directory");
        }
        return packageDirectory;
    }

    private static String validateOutputFileName(String requested, String defaultName) {
        String fileName = requested == null ? defaultName : requested;
        if (!OUTPUT_FILE_PATTERN.matcher(fileName).matches()
                || fileName.contains("..") || fileName.contains("/") || fileName.contains("\\")) {
            throw new IllegalArgumentException(
                    "outputFileName must be a simple .csv filename containing only letters, digits, _, $, ., or -");
        }
        return fileName;
    }

    private static Map<String, List<ServiceEntry>> buildServiceIndex(
            Path packagesDirectory, final LinkedHashSet<String> warnings) throws IOException {

        final Map<String, List<ServiceEntry>> index = new LinkedHashMap<String, List<ServiceEntry>>();
        List<Path> packageDirectories = listDirectories(packagesDirectory);

        for (final Path packageDirectory : packageDirectories) {
            final Path namespaceDirectory = packageDirectory.resolve("ns");
            if (!Files.isDirectory(namespaceDirectory) || Files.isSymbolicLink(namespaceDirectory)) {
                continue;
            }

            try {
                Files.walkFileTree(namespaceDirectory, new SimpleFileVisitor<Path>() {
                    @Override
                    public FileVisitResult preVisitDirectory(Path directory, BasicFileAttributes attributes) {
                        if (!directory.equals(namespaceDirectory) && Files.isSymbolicLink(directory)) {
                            return FileVisitResult.SKIP_SUBTREE;
                        }
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult postVisitDirectory(Path directory, IOException error) {
                        if (error != null) {
                            warnings.add(directory + ": " + error.getMessage());
                            return FileVisitResult.CONTINUE;
                        }
                        Path flowXml = directory.resolve("flow.xml");
                        Path nodeNdf = directory.resolve("node.ndf");
                        if (!Files.isRegularFile(flowXml) && !Files.isRegularFile(nodeNdf)) {
                            return FileVisitResult.CONTINUE;
                        }
                        String serviceName = namespaceName(namespaceDirectory, directory);
                        if (serviceName == null) {
                            return FileVisitResult.CONTINUE;
                        }
                        ServiceEntry entry = new ServiceEntry(
                                packageDirectory.getFileName().toString(),
                                serviceName,
                                directory,
                                flowXml);
                        List<ServiceEntry> entries = index.get(serviceName);
                        if (entries == null) {
                            entries = new ArrayList<ServiceEntry>();
                            index.put(serviceName, entries);
                        }
                        entries.add(entry);
                        return FileVisitResult.CONTINUE;
                    }

                    @Override
                    public FileVisitResult visitFileFailed(Path file, IOException error) {
                        warnings.add(file + ": " + error.getMessage());
                        return FileVisitResult.CONTINUE;
                    }
                });
            } catch (IOException error) {
                warnings.add(namespaceDirectory + ": " + error.getMessage());
            }
        }

        for (List<ServiceEntry> entries : index.values()) {
            Collections.sort(entries, SERVICE_ENTRY_COMPARATOR);
        }
        return index;
    }

    private static DiscoveryResult discoverRestResources(
            Path packageDirectory,
            Map<String, List<ServiceEntry>> serviceIndex,
            LinkedHashSet<String> warnings) throws IOException {

        final Path namespaceDirectory = packageDirectory.resolve("ns");
        if (!Files.isDirectory(namespaceDirectory)) {
            throw new IllegalArgumentException(
                    "Package has no ns directory: " + packageDirectory.getFileName());
        }

        List<Path> directories = collectDirectories(namespaceDirectory, warnings);
        Set<RestResource> resources = new TreeSet<RestResource>(REST_RESOURCE_COMPARATOR);
        int detectedResourceCount = 0;

        for (Path elementDirectory : directories) {
            String apiName = namespaceName(namespaceDirectory, elementDirectory);
            if (apiName == null) {
                continue;
            }

            Set<String> parents = legacyOperationParents(elementDirectory, namespaceDirectory);
            List<byte[]> metadataBlobs = new ArrayList<byte[]>();
            boolean markedAsRest = false;

            for (Path metadataPath : metadataPaths(elementDirectory)) {
                try {
                    byte[] data = readLimited(metadataPath);
                    metadataBlobs.add(data);
                    if (metadataMarksRestResource(data)) {
                        markedAsRest = true;
                    }
                } catch (Exception error) {
                    warnings.add(metadataPath + ": " + error.getMessage());
                }
            }

            if (parents.isEmpty() && !markedAsRest) {
                continue;
            }

            detectedResourceCount++;
            for (byte[] metadata : metadataBlobs) {
                for (String reference : serviceReferences(metadata)) {
                    List<ServiceEntry> entries = serviceIndex.get(reference);
                    if (containsFlow(entries)) {
                        parents.add(reference);
                    }
                }
            }

            if (parents.isEmpty()) {
                warnings.add("REST resource has no statically resolvable Flow parent: " + apiName);
                continue;
            }

            for (String parent : parents) {
                resources.add(new RestResource(apiName, parent));
            }
        }

        return new DiscoveryResult(
                new ArrayList<RestResource>(resources), detectedResourceCount);
    }

    private static List<Path> collectDirectories(
            final Path root, final LinkedHashSet<String> warnings) throws IOException {

        final List<Path> directories = new ArrayList<Path>();
        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path directory, BasicFileAttributes attributes) {
                if (!directory.equals(root) && Files.isSymbolicLink(directory)) {
                    return FileVisitResult.SKIP_SUBTREE;
                }
                directories.add(directory);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException error) {
                warnings.add(file + ": " + error.getMessage());
                return FileVisitResult.CONTINUE;
            }
        });
        Collections.sort(directories, PATH_COMPARATOR);
        return directories;
    }

    private static Set<String> legacyOperationParents(
            Path resourceDirectory, Path namespaceDirectory) throws IOException {

        Set<String> parents = new TreeSet<String>(STRING_COMPARATOR);
        List<Path> childDirectories = listDirectories(resourceDirectory);
        for (Path child : childDirectories) {
            String childName = child.getFileName().toString().toLowerCase(Locale.ROOT);
            if (!REST_OPERATION_NAMES.contains(childName)) {
                continue;
            }
            if (!Files.isRegularFile(child.resolve("flow.xml"))) {
                continue;
            }
            String serviceName = namespaceName(namespaceDirectory, child);
            if (serviceName != null) {
                parents.add(serviceName);
            }
        }
        return parents;
    }

    private static List<Path> metadataPaths(Path elementDirectory) throws IOException {
        List<Path> paths = new ArrayList<Path>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(elementDirectory)) {
            for (Path path : stream) {
                if (!Files.isRegularFile(path)) {
                    continue;
                }
                String fileName = path.getFileName().toString().toLowerCase(Locale.ROOT);
                if ("node.ndf".equals(fileName) || "node.idf".equals(fileName)) {
                    paths.add(path);
                }
            }
        }
        Collections.sort(paths, PATH_COMPARATOR);
        return paths;
    }

    private static byte[] readLimited(Path path) throws IOException {
        long size = Files.size(path);
        if (size > MAX_XML_BYTES) {
            throw new IOException("file is larger than 32 MiB");
        }
        return Files.readAllBytes(path);
    }

    private static boolean metadataMarksRestResource(byte[] data) {
        String folded = new String(data, StandardCharsets.ISO_8859_1).toLowerCase(Locale.ROOT);
        String compact = folded.replaceAll("[^a-z0-9]+", "");

        if (compact.contains("nodetyperestdescriptor")
                || compact.contains("nodetyperestapidescriptor")) {
            return false;
        }

        return compact.contains("nodetyperestresource")
                || compact.contains("nodetyperestv2resource")
                || compact.contains("subtyperestresource")
                || compact.contains("subtyperestv2resource")
                || compact.contains("subtyperest")
                || compact.contains("isrestresourcetrue");
    }

    private static Set<String> serviceReferences(byte[] data) {
        Set<String> references = new TreeSet<String>(STRING_COMPARATOR);
        Matcher matcher = SERVICE_REFERENCE_PATTERN.matcher(
                new String(data, StandardCharsets.ISO_8859_1));
        while (matcher.find()) {
            references.add(matcher.group(1));
        }
        return references;
    }

    private static boolean containsFlow(List<ServiceEntry> entries) {
        if (entries == null) {
            return false;
        }
        for (ServiceEntry entry : entries) {
            if (entry.isFlow()) {
                return true;
            }
        }
        return false;
    }

    private static List<Path> listDirectories(Path parent) throws IOException {
        List<Path> directories = new ArrayList<Path>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(parent)) {
            for (Path path : stream) {
                if (Files.isDirectory(path) && !Files.isSymbolicLink(path)) {
                    directories.add(path);
                }
            }
        }
        Collections.sort(directories, PATH_COMPARATOR);
        return directories;
    }

    private static String namespaceName(Path namespaceDirectory, Path elementDirectory) {
        Path normalizedNamespace = namespaceDirectory.toAbsolutePath().normalize();
        Path normalizedElement = elementDirectory.toAbsolutePath().normalize();
        if (!normalizedElement.startsWith(normalizedNamespace)) {
            return null;
        }

        Path relative = normalizedNamespace.relativize(normalizedElement);
        if (relative.getNameCount() < 2) {
            return null;
        }

        StringBuilder name = new StringBuilder();
        for (int index = 0; index < relative.getNameCount() - 1; index++) {
            if (index > 0) {
                name.append('.');
            }
            name.append(relative.getName(index).toString());
        }
        name.append(':').append(relative.getName(relative.getNameCount() - 1).toString());
        return name.toString();
    }

    private static List<Invoke> parseFlowInvokes(Path flowXml) throws Exception {
        byte[] data = readLimited(flowXml);
        String upper = new String(data, StandardCharsets.ISO_8859_1).toUpperCase(Locale.ROOT);
        if (upper.contains("<!DOCTYPE") || upper.contains("<!ENTITY")) {
            throw new IllegalArgumentException("DTD/entity declarations are not supported");
        }

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setExpandEntityReferences(false);
        try {
            factory.setXIncludeAware(false);
        } catch (UnsupportedOperationException ignored) {
            // The explicit declaration check above still blocks entity declarations.
        }
        setFeatureIfSupported(factory, "http://apache.org/xml/features/disallow-doctype-decl", true);
        setFeatureIfSupported(factory, "http://xml.org/sax/features/external-general-entities", false);
        setFeatureIfSupported(factory, "http://xml.org/sax/features/external-parameter-entities", false);
        setFeatureIfSupported(factory, "http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new ByteArrayInputStream(data));
        Element root = document.getDocumentElement();
        if (root == null || !"FLOW".equals(localTag(root))) {
            throw new IllegalArgumentException("Expected FLOW XML root; verify storage format");
        }

        List<Invoke> invokes = new ArrayList<Invoke>();
        visitFlow(root, false, invokes);
        return invokes;
    }

    private static void setFeatureIfSupported(
            DocumentBuilderFactory factory, String feature, boolean value) {
        try {
            factory.setFeature(feature, value);
        } catch (Exception ignored) {
            // Manual rejection of DTD/entity declarations remains enforced.
        }
    }

    private static void visitFlow(Element element, boolean inheritedDisabled, List<Invoke> invokes) {
        boolean disabled = inheritedDisabled || parseBoolean(attributeIgnoreCase(element, "DISABLED"));
        if ("INVOKE".equals(localTag(element))) {
            String target = trimToNull(attributeIgnoreCase(element, "SERVICE"));
            invokes.add(new Invoke(target == null ? "" : target, disabled));
        }

        NodeList children = element.getChildNodes();
        for (int index = 0; index < children.getLength(); index++) {
            Node child = children.item(index);
            if (child instanceof Element) {
                visitFlow((Element) child, disabled, invokes);
            }
        }
    }

    private static String attributeIgnoreCase(Element element, String name) {
        NamedNodeMap attributes = element.getAttributes();
        for (int index = 0; index < attributes.getLength(); index++) {
            Node attribute = attributes.item(index);
            String localName = attribute.getLocalName();
            String nodeName = localName == null ? attribute.getNodeName() : localName;
            if (name.equalsIgnoreCase(nodeName)) {
                return attribute.getNodeValue();
            }
        }
        return "";
    }

    private static String localTag(Node node) {
        String name = node.getLocalName();
        if (name == null) {
            name = node.getNodeName();
            int colon = name.indexOf(':');
            if (colon >= 0) {
                name = name.substring(colon + 1);
            }
        }
        return name.toUpperCase(Locale.ROOT);
    }

    private static boolean packageIsIncluded(String packageName) {
        String folded = packageName.toLowerCase(Locale.ROOT);
        return folded.startsWith(CHILD_PACKAGE_PREFIX.toLowerCase(Locale.ROOT))
                && !folded.equals(EXCLUDED_PACKAGE.toLowerCase(Locale.ROOT));
    }

    private static boolean serviceLooksExcluded(String serviceName) {
        String folded = serviceName.toLowerCase(Locale.ROOT);
        String excluded = EXCLUDED_PACKAGE.toLowerCase(Locale.ROOT);
        return folded.equals(excluded) || folded.startsWith(excluded + ".");
    }

    private static String buildCsv(Set<Row> rows) {
        StringBuilder csv = new StringBuilder();
        csv.append("api_name,parent_service_name,child_invoke_service_name\r\n");
        for (Row row : rows) {
            csv.append(csvValue(row.apiName)).append(',')
                    .append(csvValue(row.parentServiceName)).append(',')
                    .append(csvValue(row.childServiceName)).append("\r\n");
        }
        return csv.toString();
    }

    private static String csvValue(String value) {
        String safe = value == null ? "" : value;
        if (!safe.isEmpty()) {
            char first = safe.charAt(0);
            if (first == '=' || first == '+' || first == '-' || first == '@') {
                safe = "'" + safe;
            }
        }
        if (safe.indexOf(',') >= 0 || safe.indexOf('"') >= 0
                || safe.indexOf('\r') >= 0 || safe.indexOf('\n') >= 0) {
            return '"' + safe.replace("\"", "\"\"") + '"';
        }
        return safe;
    }

    private static Path writeCsvAtomically(
            Path reportsDirectory, String outputFileName, String csvData) throws IOException {

        Path normalizedReports = reportsDirectory.toAbsolutePath().normalize();
        Files.createDirectories(normalizedReports);
        Path destination = normalizedReports.resolve(outputFileName).normalize();
        if (!destination.getParent().equals(normalizedReports)) {
            throw new IllegalArgumentException("Output path escapes the reports directory");
        }

        Path temporary = Files.createTempFile(normalizedReports, ".nbk-flow-invokes-", ".tmp");
        try {
            byte[] content = ("\uFEFF" + csvData).getBytes(StandardCharsets.UTF_8);
            Files.write(temporary, content);
            try {
                Files.move(
                        temporary,
                        destination,
                        StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException unsupported) {
                Files.move(temporary, destination, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
        return destination;
    }

    private static boolean parseBoolean(String value) {
        if (value == null) {
            return false;
        }
        String folded = value.trim().toLowerCase(Locale.ROOT);
        return "true".equals(folded) || "1".equals(folded) || "yes".equals(folded);
    }

    private static String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }

    private static String join(Iterable<String> values, String separator) {
        StringBuilder result = new StringBuilder();
        for (String value : values) {
            if (result.length() > 0) {
                result.append(separator);
            }
            result.append(value);
        }
        return result.toString();
    }

    private static final class FlowGraph {
        private final Map<String, List<ServiceEntry>> serviceIndex;
        private final boolean includeDisabled;
        private final LinkedHashSet<String> warnings;
        private final Map<Path, List<Invoke>> invokeCache = new HashMap<Path, List<Invoke>>();
        private final Set<String> unresolvedNbKTargets = new TreeSet<String>(STRING_COMPARATOR);

        private FlowGraph(
                Map<String, List<ServiceEntry>> serviceIndex,
                boolean includeDisabled,
                LinkedHashSet<String> warnings) {
            this.serviceIndex = serviceIndex;
            this.includeDisabled = includeDisabled;
            this.warnings = warnings;
        }

        private Set<String> recursiveChildren(String parentServiceName) {
            List<ServiceEntry> parentEntries = new ArrayList<ServiceEntry>();
            List<ServiceEntry> indexedParents = serviceIndex.get(parentServiceName);
            if (indexedParents != null) {
                for (ServiceEntry entry : indexedParents) {
                    if (entry.isFlow()) {
                        parentEntries.add(entry);
                    }
                }
            }

            if (parentEntries.isEmpty()) {
                warnings.add("Parent is not a resolvable Flow service: " + parentServiceName);
                return Collections.emptySet();
            }

            Set<String> children = new TreeSet<String>(STRING_COMPARATOR);
            Set<Path> visitedFlows = new HashSet<Path>();
            Deque<ServiceEntry> stack = new ArrayDeque<ServiceEntry>();
            for (int index = parentEntries.size() - 1; index >= 0; index--) {
                stack.push(parentEntries.get(index));
            }

            while (!stack.isEmpty()) {
                ServiceEntry entry = stack.pop();
                Path flowKey = entry.flowXml.toAbsolutePath().normalize();
                if (!visitedFlows.add(flowKey)) {
                    continue;
                }

                for (Invoke invoke : invokesFor(entry)) {
                    if (invoke.targetServiceName.isEmpty()) {
                        continue;
                    }
                    if (invoke.disabled && !includeDisabled) {
                        continue;
                    }

                    List<ServiceEntry> targetEntries = includedEntries(invoke.targetServiceName);
                    if (targetEntries.isEmpty()) {
                        continue;
                    }

                    if (!invoke.targetServiceName.equalsIgnoreCase(parentServiceName)) {
                        children.add(invoke.targetServiceName);
                    }

                    for (int index = targetEntries.size() - 1; index >= 0; index--) {
                        ServiceEntry targetEntry = targetEntries.get(index);
                        if (targetEntry.isFlow()) {
                            stack.push(targetEntry);
                        }
                    }
                }
            }
            return children;
        }

        private List<Invoke> invokesFor(ServiceEntry entry) {
            Path key = entry.flowXml.toAbsolutePath().normalize();
            List<Invoke> cached = invokeCache.get(key);
            if (cached != null) {
                return cached;
            }
            try {
                cached = parseFlowInvokes(entry.flowXml);
            } catch (Exception error) {
                warnings.add(entry.flowXml + ": " + error.getMessage());
                cached = Collections.emptyList();
            }
            invokeCache.put(key, cached);
            return cached;
        }

        private List<ServiceEntry> includedEntries(String serviceName) {
            if (serviceLooksExcluded(serviceName)) {
                return Collections.emptyList();
            }

            List<ServiceEntry> included = new ArrayList<ServiceEntry>();
            List<ServiceEntry> entries = serviceIndex.get(serviceName);
            if (entries != null) {
                for (ServiceEntry entry : entries) {
                    if (packageIsIncluded(entry.packageName)) {
                        included.add(entry);
                    }
                }
            }

            if (included.isEmpty()
                    && serviceName.toLowerCase(Locale.ROOT).startsWith(
                            CHILD_PACKAGE_PREFIX.toLowerCase(Locale.ROOT))) {
                unresolvedNbKTargets.add(serviceName);
            }
            return included;
        }
    }

    static final class ExportResult {
        final String csvFileName;
        final Path csvPath;
        final int apiCount;
        final int parentServiceCount;
        final int rowCount;
        final List<String> warnings;
        final String csvData;

        ExportResult(
                String csvFileName,
                Path csvPath,
                int apiCount,
                int parentServiceCount,
                int rowCount,
                List<String> warnings,
                String csvData) {
            this.csvFileName = csvFileName;
            this.csvPath = csvPath;
            this.apiCount = apiCount;
            this.parentServiceCount = parentServiceCount;
            this.rowCount = rowCount;
            this.warnings = warnings;
            this.csvData = csvData;
        }
    }

    private static final class ServiceEntry {
        final String packageName;
        final String serviceName;
        final Path directory;
        final Path flowXml;

        ServiceEntry(String packageName, String serviceName, Path directory, Path flowXml) {
            this.packageName = packageName;
            this.serviceName = serviceName;
            this.directory = directory;
            this.flowXml = flowXml;
        }

        boolean isFlow() {
            return Files.isRegularFile(flowXml);
        }
    }

    private static final class RestResource {
        final String apiName;
        final String parentServiceName;

        RestResource(String apiName, String parentServiceName) {
            this.apiName = apiName;
            this.parentServiceName = parentServiceName;
        }
    }

    private static final class DiscoveryResult {
        final List<RestResource> resources;
        final int detectedResourceCount;

        DiscoveryResult(List<RestResource> resources, int detectedResourceCount) {
            this.resources = resources;
            this.detectedResourceCount = detectedResourceCount;
        }
    }

    private static final class Invoke {
        final String targetServiceName;
        final boolean disabled;

        Invoke(String targetServiceName, boolean disabled) {
            this.targetServiceName = targetServiceName;
            this.disabled = disabled;
        }
    }

    private static final class Row {
        final String apiName;
        final String parentServiceName;
        final String childServiceName;

        Row(String apiName, String parentServiceName, String childServiceName) {
            this.apiName = apiName;
            this.parentServiceName = parentServiceName;
            this.childServiceName = childServiceName;
        }
    }

    private static final Comparator<String> STRING_COMPARATOR = new Comparator<String>() {
        @Override
        public int compare(String first, String second) {
            int insensitive = first.compareToIgnoreCase(second);
            return insensitive != 0 ? insensitive : first.compareTo(second);
        }
    };

    private static final Comparator<Path> PATH_COMPARATOR = new Comparator<Path>() {
        @Override
        public int compare(Path first, Path second) {
            return STRING_COMPARATOR.compare(first.toString(), second.toString());
        }
    };

    private static final Comparator<ServiceEntry> SERVICE_ENTRY_COMPARATOR = new Comparator<ServiceEntry>() {
        @Override
        public int compare(ServiceEntry first, ServiceEntry second) {
            int byPackage = STRING_COMPARATOR.compare(first.packageName, second.packageName);
            if (byPackage != 0) {
                return byPackage;
            }
            return PATH_COMPARATOR.compare(first.directory, second.directory);
        }
    };

    private static final Comparator<RestResource> REST_RESOURCE_COMPARATOR = new Comparator<RestResource>() {
        @Override
        public int compare(RestResource first, RestResource second) {
            int byApi = STRING_COMPARATOR.compare(first.apiName, second.apiName);
            if (byApi != 0) {
                return byApi;
            }
            return STRING_COMPARATOR.compare(first.parentServiceName, second.parentServiceName);
        }
    };

    private static final Comparator<Row> ROW_COMPARATOR = new Comparator<Row>() {
        @Override
        public int compare(Row first, Row second) {
            int byApi = STRING_COMPARATOR.compare(first.apiName, second.apiName);
            if (byApi != 0) {
                return byApi;
            }
            int byParent = STRING_COMPARATOR.compare(
                    first.parentServiceName, second.parentServiceName);
            if (byParent != 0) {
                return byParent;
            }
            return STRING_COMPARATOR.compare(first.childServiceName, second.childServiceName);
        }
    };
}
