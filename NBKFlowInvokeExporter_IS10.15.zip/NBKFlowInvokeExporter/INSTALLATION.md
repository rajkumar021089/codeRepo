# Installation and execution

## Install on Integration Server 10.15

Test this utility in a non-production Integration Server first.

1. Extract the ZIP into the Integration Server instance `packages` directory.
2. Confirm the final path is `<instance>/packages/NBKFlowInvokeExporter/manifest.v3`.
3. If Integration Server is running, open **Packages > Management** and activate/reload
   `NBKFlowInvokeExporter`. Otherwise, start Integration Server.
4. Confirm the package loaded without errors.

The package contains Java 8-compatible bytecode and uses only Integration Server APIs and
Java standard-library classes; no external JAR is required.

## Run from Designer

Run this Flow service:

```text
NBKFlowInvokeExporter.services:exportPackageInvokes
```

Example input:

```text
packageName       = NBKCmrPayment
outputFileName    = NBKCmrPayment_Dependencies.csv   (optional)
includeDisabled   = false                             (optional)
```

Main outputs:

```text
status
csvFileName
csvPath
apiCount
parentServiceCount
rowCount
warningCount
warnings[]
csvData
```

The physical CSV is written to:

```text
<instance>/packages/NBKFlowInvokeExporter/pub/reports/<outputFileName>
```

The service also returns the CSV text in `csvData`.

## Meaning of the columns

- `api_name`: REST resource namespace name discovered in the supplied package.
- `parent_service_name`: REST operation Flow or associated REST V2 implementation Flow.
- `child_invoke_service_name`: every unique recursively reachable INVOKE whose owning
  package starts with `NBK`, excluding `NBKLoggingPub`.

## Important limitations

- This is a static, read-only scan; it does not invoke business services.
- Dynamically constructed service names cannot be resolved.
- Java, adapter, and other non-Flow services can be listed as children but are not expanded.
- Runtime path decisions, pipeline-supplied destinations, and package enablement are not
  execution-traced.
- REST metadata varies between fixes and project styles. Review `warnings[]` and validate a
  sample API against Designer before using the CSV for architecture decisions.
- The scan can be expensive on a large server. Run it during a low-traffic period and only
  grant execution access to trusted developers or administrators.
